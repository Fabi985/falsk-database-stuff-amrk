var milliseconds = 5000;

setTimeout(function () {
    document.getElementById('flash-killer').remove();
}, milliseconds);